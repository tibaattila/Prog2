function pnk=pnk_d4(k,n)
d=4;
p = ones(1,d)/d;   %[1/2 1/3 1/6];
%n = 10;
x1 = 0:k;
x2 = 0:k;
x3= 0:k;
[X1,X2,X3] = meshgrid(x1,x2,x3);
X4 = n-k-(X1+X2+X3);
Y = mnpdf([X1(:),X2(:),X3(:),X4(:)],repmat(p,(k+1)^(d-1),1));
alf1=[X1(:),X2(:),X3(:),X4(:)]-k;
alf= sum( alf1==0,2)+1;
beta=logical(prod(alf1<=0,2));
pnk=sum(Y(beta)./(alf(beta)));