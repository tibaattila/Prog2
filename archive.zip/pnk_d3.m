function pnk=pnk_d3(k,n)
d=3;
p = ones(1,d)/d;   %[1/2 1/3 1/6];
%n = 10;
x1 = 0:k;
x2 = 0:k;
[X1,X2] = meshgrid(x1,x2);
X3 = n-k-(X1+X2);
Y = mnpdf([X1(:),X2(:),X3(:)],repmat(p,(k+1)^2,1));
alf1=[X1(:),X2(:),X3(:)]-k;
alf= sum( alf1==0,2)+1;
beta=logical(prod(alf1<=0,2));

% [Y,alf,Y./alf]
pnk=sum(Y(beta)./(alf(beta)));